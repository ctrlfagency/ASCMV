exports.render = function(req, res) {
    res.render('vocal', {
    	title: 'Reconnaissance Vocale - ASCMV : Association Spinalienne Culturelle Musulmane des Vosges'
    });
};
