exports.render = function(req, res) {
    res.render('telechargement', {
    	title: 'Téléchargement & Licences - ASCMV : Association Spinalienne Culturelle Musulmane des Vosges'
    });
};
