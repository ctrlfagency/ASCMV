exports.render = function(req, res) {
    res.render('api', {
    	title: 'Documentation API - ASCMV : Association Spinalienne Culturelle Musulmane des Vosges'
    });
};
