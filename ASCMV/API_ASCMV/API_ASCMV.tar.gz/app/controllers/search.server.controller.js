exports.render = function(req, res) {
    res.render('search', {
    	title: 'Moteur de recherche - ASCMV : Association Spinalienne Culturelle Musulmane des Vosges'
    });
};
