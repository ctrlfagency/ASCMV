exports.render = function(req, res) {
    res.render('site', {
    	title: 'Site Web - Mentions Légales - ASCMV : Association Spinalienne Culturelle Musulmane des Vosges'
    });
};
