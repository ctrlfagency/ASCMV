exports.render = function(req, res) {
    res.render('index', {
    	title: 'ASCMV : Association Spinalienne Culturelle Musulmane des Vosges - Horaires de prières'
    });
};
